(() => {
      const el = (q) => document.querySelector(q);
      const els = (q) => Array.from(document.querySelectorAll(q));

      const state = {
        cfg: null,
        cart: []
      };

      function cartKey() {
        const slug = state.cfg?.store?.slug || "store";
        return "ch_cart_" + slug;
      }

      function loadCart() {
        try {
          const raw = localStorage.getItem(cartKey());
          state.cart = raw ? JSON.parse(raw) : [];
        } catch {
          state.cart = [];
        }
      }

      function saveCart() {
        localStorage.setItem(cartKey(), JSON.stringify(state.cart));
      }

      function money(n) {
        return "R " + Number(n || 0).toFixed(2);
      }

      function findProduct(sku) {
        return (state.cfg?.products || []).find(p => p.sku === sku);
      }

      function addToCart(sku) {
        const item = state.cart.find(i => i.sku === sku);
        if (item) item.qty += 1;
        else state.cart.push({ sku, qty: 1 });
        saveCart();
        renderCart();
      }

      function setQty(sku, qty) {
        qty = Math.max(1, Math.min(99, parseInt(qty, 10) || 1));
        const item = state.cart.find(i => i.sku === sku);
        if (item) item.qty = qty;
        saveCart();
        renderCart();
      }

      function removeItem(sku) {
        state.cart = state.cart.filter(i => i.sku !== sku);
        saveCart();
        renderCart();
      }

      function calcTotal() {
        let total = 0;
        for (const it of state.cart) {
          const p = findProduct(it.sku);
          if (!p) continue;
          total += Number(p.price) * Number(it.qty);
        }
        return total;
      }

      function renderProducts() {
        const grid = el("#products");
        const prods = state.cfg?.products || [];
        if (!prods.length) {
          grid.innerHTML = '<div class="muted">No products yet. Add products in commercehub.config.json → deploy.</div>';
          return;
        }

        grid.innerHTML = prods.map(p => `
          <div class="card">
            <div class="card__title">${escapeHtml(p.name)}</div>
            <div class="card__meta">${escapeHtml(p.sku)} • <b>${money(p.price)}</b></div>
            <button class="btn" data-add="${escapeHtml(p.sku)}">Add to cart</button>
          </div>
        `).join("");

        els("[data-add]").forEach(b => {
          b.addEventListener("click", () => addToCart(b.getAttribute("data-add")));
        });
      }

      function renderCart() {
        const cartBox = el("#cartItems");
        const totalBox = el("#cartTotal");
        const countBox = el("#cartCount");

        const count = state.cart.reduce((a, b) => a + (b.qty || 0), 0);
        countBox.textContent = String(count);

        if (!state.cart.length) {
          cartBox.innerHTML = '<div class="muted">Cart is empty.</div>';
          totalBox.textContent = money(0);
          return;
        }

        cartBox.innerHTML = state.cart.map(it => {
          const p = findProduct(it.sku);
          const name = p ? p.name : it.sku;
          const price = p ? Number(p.price) : 0;
          const line = price * Number(it.qty);

          return `
            <div class="cartRow">
              <div class="cartRow__info">
                <div class="cartRow__name">${escapeHtml(name)}</div>
                <div class="cartRow__meta">${escapeHtml(it.sku)} • ${money(price)} each</div>
              </div>
              <div class="cartRow__controls">
                <input class="qty" type="number" min="1" max="99" value="${it.qty}" data-qty="${escapeHtml(it.sku)}" />
                <div class="cartRow__line">${money(line)}</div>
                <button class="btn btn--ghost" data-rm="${escapeHtml(it.sku)}">Remove</button>
              </div>
            </div>
          